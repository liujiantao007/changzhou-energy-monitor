# Energy Charge Daily Summary 更新脚本使用说明

## 📋 文档信息

| 项目 | 内容 |
|------|------|
| **脚本名称** | `update_daily_summary.py` |
| **位置** | 项目根目录 |
| **功能** | 更新 `energy_charge_daily_summary` 汇总表，支持批量和单日更新 |
| **数据库** | 能源管理系统数据库 |

---

## 🚀 快速开始

### 1. 修改数据库配置

编辑脚本中的数据库连接信息（文件开头第 32-42 行）：

```python
DB_CONFIG = {
    'host': '10.38.78.217',      # 数据库地址
    'port': 3220,                 # 数据库端口
    'user': 'liujiantao',          # 数据库用户名
    'password': 'Liujt!@#',       # 数据库密码
    'database': 'energy_management_2026',  # 数据库名
    'charset': 'utf8mb4',
    'connect_timeout': 60,
    'read_timeout': 300,
    'write_timeout': 300
}
```

### 2. 运行脚本

```bash
# 方式一：更新所有日期（推荐首次使用）
python update_daily_summary.py

# 方式二：更新指定日期
python update_daily_summary.py 2026-03-20
```

---

## 📝 使用方式

### 方式一：无参数（批量更新）

```bash
python update_daily_summary.py
```

**功能**：
- 自动获取 `energy_charge` 源表中所有日期
- 逐日更新 `energy_charge_daily_summary` 汇总表
- 显示处理进度和成功/失败统计

**输出示例**：
```
============================================================
找到 41 个可用日期

[1/41] 正在处理 2026-02-15...
[1/41] 2026-02-15 更新成功 ✅

[2/41] 正在处理 2026-02-16...
[2/41] 2026-02-16 更新成功 ✅

...

============================================================
批量更新完成!
  总日期数: 41
  成功: 41 个
  失败: 0 个
============================================================
```

### 方式二：指定日期（单日更新）

```bash
python update_daily_summary.py 2026-03-20
```

**支持的日期格式**：
| 格式 | 示例 |
|------|------|
| YYYY-MM-DD | `2026-03-20` |
| YYYY/MM/DD | `2026/03/20` |
| YYYYMMDD | `20260320` |

**输出示例**：
```
============================================================
开始更新 2026-03-20 的数据
============================================================
正在检查源表是否存在 2026-03-20 的数据...
源表有 1200 条记录

[步骤 1/2] 删除旧数据...
已删除 15 条 2026-03-20 的数据

[步骤 2/2] 插入新数据...
成功插入 15 条聚合数据
事务已提交

正在验证数据一致性...

------------------------------------------------------------
数据一致性验证报告 - 2026-03-20
------------------------------------------------------------
指标              源表                  目标表                差异         状态
------------------------------------------------------------
记录数            1200                  1200                 0            ✅
总度数            123456.78             123456.78            0.00         ✅
总电费            98765.43              98765.43             0.00         ✅
------------------------------------------------------------

============================================================
更新完成!
  日期: 2026-03-20
  源表记录: 1200
  删除: 15 条
  插入: 15 条
  耗时: 5.23 秒
  状态: ✅ 成功
============================================================
```

---

## ⚙️ 处理逻辑

### 单日更新流程

```
1. 验证日期格式
2. 检查源表（energy_charge）中是否存在该日期的数据
3. 删除目标表（energy_charge_daily_summary）中该日期的旧数据
4. 从源表聚合数据并插入目标表
5. 验证数据一致性（记录数、度数、电费）
6. 输出执行结果
```

### 批量更新流程

```
1. 获取源表中所有可用日期
2. 遍历每个日期，执行单日更新流程
3. 统计成功/失败数量
4. 输出最终汇总报告
```

### 聚合维度

数据按以下维度聚合：
- **日期**（stat_date）
- **区县**（district）
- **网格**（grid）

---

## 📊 数据表说明

### 源表：energy_charge

存储每日用电明细数据。

| 关键字段 | 说明 |
|---------|------|
| 日期 | 记录日期 |
| 归属单元 | 区县名称 |
| 归属网格 | 网格名称 |
| 电表 | 电表编号 |
| 度数 | 用电量 (kWh) |
| 电费 | 费用 (元) |

### 目标表：energy_charge_daily_summary

存储按日/区县/网格聚合的汇总数据。

| 字段 | 说明 |
|------|------|
| stat_date | 汇总日期 |
| district | 区县 |
| grid | 网格 |
| total_energy | 总用电量 |
| total_cost | 总电费 |
| record_count | 原始记录数 |

---

## 🛠️ 常见问题

### Q1: 脚本执行失败怎么办？

**检查项**：
1. 数据库连接信息是否正确
2. 网络是否能访问数据库
3. 数据库用户是否有读写权限

### Q2: 批量更新可以中断吗？

可以。使用 `Ctrl + C` 中断，但已处理的数据不会回滚。

### Q3: 如何只更新特定日期范围？

目前脚本不支持日期范围参数。可以修改代码实现：

```python
# 在 get_all_available_dates() 中添加 WHERE 条件
cursor.execute("""
    SELECT DISTINCT 日期 FROM energy_charge
    WHERE 日期 >= '2026-01-01' AND 日期 <= '2026-03-31'
    ORDER BY 日期 DESC
""")
```

### Q4: 数据验证失败怎么办？

脚本会自动检查记录数、度数、电费是否一致。如果差异超过 0.01，会提示失败。

可能原因：
- 源表数据被修改
- 聚合 SQL 与源表结构不匹配

### Q5: 批量更新太慢怎么办？

可以分批执行单日更新：

```bash
# 分批执行
python update_daily_summary.py 2026-01-01
python update_daily_summary.py 2026-02-01
python update_daily_summary.py 2026-03-01
```

---

## 📋 使用场景

| 场景 | 推荐命令 |
|------|---------|
| **首次部署** | `python update_daily_summary.py`（批量更新所有日期） |
| **修复某一天** | `python update_daily_summary.py 2026-03-20` |
| **补充用电方字段** | `python update_consumer_fields.py 2026-03-20` |
| **定期同步** | 配合 cron 使用定时任务 |
| **测试验证** | `python update_daily_summary.py 2026-03-20` |

---

## 🔧 补充用电方维度字段

`update_daily_summary.py` 只更新基本的汇总字段，需要运行 `update_consumer_fields.py` 来补充用电方和供电类型维度的字段。

### 补充字段列表

| 字段 | 说明 |
|------|------|
| `mobile_cumulative_energy` | 移动用户日累计用电量 (kWh) |
| `mobile_poi_count` | 移动用户 POI 数量 |
| `tower_cumulative_energy` | 电塔用户日累计用电量 (kWh) |
| `tower_poi_count` | 电塔用户 POI 数量 |
| `direct_power_supply_energy` | 直供电用电量 (kWh) |
| `direct_power_supply_cost` | 直供电电费 (元) |
| `indirect_power_supply_energy` | 转供电用电量 (kWh) |
| `indirect_power_supply_cost` | 转供电电费 (元) |
| `mobile_electricity_fee` | 移动用户日累计电费 (元) |
| `tower_electricity_fee` | 铁塔用户日累计电费 (元) |

### 使用方法

```bash
# 补充所有日期的用电方字段
python update_consumer_fields.py

# 补充指定日期的用电方字段
python update_consumer_fields.py 2026-03-20
```

### 完整更新流程

```bash
# 1. 先更新基本汇总字段
python update_daily_summary.py 2026-03-20

# 2. 再补充用电方维度字段
python update_consumer_fields.py 2026-03-20

# 或者一次性更新所有日期（两个脚本都要运行）
python update_daily_summary.py
python update_consumer_fields.py
```

### 完整更新脚本

为了方便，可以创建一个批处理脚本 `update_all.sh`：

```bash
#!/bin/bash
# 更新所有日期的所有字段

echo ">>> 开始更新所有日期..."

echo "[1/2] 更新基本汇总字段..."
python update_daily_summary.py

echo "[2/2] 补充用电方维度字段..."
python update_consumer_fields.py

echo ">>> 更新完成!"
```

---

## 🔧 定时任务配置（可选）

### 使用 cron（每天凌晨 2 点执行）

```bash
crontab -e

# 添加以下行
0 2 * * * cd /path/to/project && python update_daily_summary.py >> logs/update.log 2>&1
```

### 查看执行日志

```bash
tail -f logs/update.log
```

---

## 📞 故障排查

### 错误信息对照

| 错误信息 | 可能原因 | 解决方案 |
|---------|---------|---------|
| `Connection refused` | 数据库地址/端口错误 | 检查 host 和 port 配置 |
| `Access denied` | 用户名/密码错误 | 检查 user 和 password |
| `Unknown database` | 数据库名不存在 | 检查 database 配置 |
| `源表中不存在 xxx 的数据` | 该日期没有源数据 | 确认日期是否正确 |

### 日志分析

脚本运行时会输出详细日志，包括：
- 执行步骤
- 处理记录数
- 数据验证结果

建议保存日志以便排查：

```bash
python update_daily_summary.py 2026-03-20 > update_20260320.log 2>&1
```

---

**文档版本**：v1.0
**最后更新**：2026-03-31
**适用项目**：常州能耗云驾驶舱
